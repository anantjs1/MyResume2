﻿var routeConfigApp = angular.module("app.routeConfig", ['ui.router']);
routeConfigApp.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/home");
    $stateProvider
        .state("home", {
            url: "/home",
            templateUrl: "/Views/home.html",

        })
        .state("myCareer", {
            url: "/mycareer",
            templateUrl: "/Views/myCareer.html",
            controller: "myCareerController"
            //views: {
            //    "": { templateUrl: "/Views/myCareer.html" },
            //    'leftSection@myCareer': {
            //        templateUrl: "/Modules/MyCareer/Templates/navTemplate.html"
            //    },
            //    'rightSection@myCareer': {
            //        templateUrl: "/Modules/MyCareer/Templates/contentTemplate.html"
            //    }
            //}

        })
        .state("hobbies", {
            url: "/hobbies",
            templateUrl: "/Views/hobbies.html",

        })
        .state("achievements", {
            url: "/achievements",
            templateUrl: "/Views/achievements.html",

        })

});
