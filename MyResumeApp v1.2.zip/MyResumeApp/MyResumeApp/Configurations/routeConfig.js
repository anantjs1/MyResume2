﻿var routeConfigApp = angular.module("app.routeConfig", ['ui.router']);
routeConfigApp.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/home");
    $stateProvider
        .state("home", {
            url: "/home",
            templateUrl: "/Views/home.html",

        })
        .state("myCareer", {
            url: "/mycareer",
            views: {
                "": { templateUrl: "/Views/myCareer.html" },
                'leftSection@myCareer': {
                    templateUrl: "/Modules/MyCareer/Templates/navTemplate.html"
                },
                'rightSection@myCareer': {
                    templateUrl: "/Modules/MyCareer/Templates/contentTemplate.html"
                }
            }

        })
        .state("hobbies", {
            url: "/hobbies",
            views: {
                "": { templateUrl: "/Views/hobbies.html" },
                'leftSection@hobbies': {
                    templateUrl: "/Modules/hobbies/Templates/navTemplate.html"
                },
                'rightSection@hobbies': {
                    templateUrl: "/Modules/hobbies/Templates/contentTemplate.html"
                }
            }

        })
        .state("achievements", {
            url: "/achievements",
            views: {
                "": { templateUrl: "/Views/achievements.html" },
                'leftSection@achievements': {
                    templateUrl: "/Modules/achievements/Templates/navTemplate.html"
                },
                'rightSection@achievements': {
                    templateUrl: "/Modules/achievements/Templates/contentTemplate.html"
                }
            }

        })

});
